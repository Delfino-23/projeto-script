/**
 * Escola de Dança Ritmo & Movimento - JavaScript
 * 
 * Este ficheiro contém todas as funcionalidades interativas do site,
 * seguindo as melhores práticas de clean code e acessibilidade.
 * 
 * @author Escola de Dança Ritmo & Movimento
 * @version 1.0.0
 */

'use strict';

// ===================================
// UTILITY FUNCTIONS
// ===================================

/**
 * Debounce function to limit the rate of function execution
 * @param {Function} func - Function to debounce
 * @param {number} wait - Wait time in milliseconds
 * @param {boolean} immediate - Execute immediately
 * @returns {Function} Debounced function
 */
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func.apply(this, args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(this, args);
    };
}

/**
 * Throttle function to limit function execution frequency
 * @param {Function} func - Function to throttle
 * @param {number} limit - Time limit in milliseconds
 * @returns {Function} Throttled function
 */
function throttle(func, limit) {
    let inThrottle;
    return function executedFunction(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Check if element is in viewport
 * @param {Element} element - Element to check
 * @returns {boolean} True if element is in viewport
 */
function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
}

/**
 * Animate number counting
 * @param {Element} element - Element containing the number
 * @param {number} start - Start number
 * @param {number} end - End number
 * @param {number} duration - Animation duration in milliseconds
 */
function animateNumber(element, start, end, duration) {
    const startTime = performance.now();
    const difference = end - start;
    
    function updateNumber(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function (ease-out)
        const easeOut = 1 - Math.pow(1 - progress, 3);
        const current = Math.floor(start + (difference * easeOut));
        
        element.textContent = current;
        
        if (progress < 1) {
            requestAnimationFrame(updateNumber);
        } else {
            element.textContent = end;
        }
    }
    
    requestAnimationFrame(updateNumber);
}

// ===================================
// NAVIGATION MODULE
// ===================================

const Navigation = {
    /**
     * Initialize navigation functionality
     */
    init() {
        this.setupMobileMenu();
        this.setupSmoothScrolling();
        this.setupActiveNavigation();
    },

    /**
     * Setup mobile menu toggle functionality
     */
    setupMobileMenu() {
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (!navToggle || !navMenu) return;

        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            
            // Toggle ARIA attributes
            navToggle.setAttribute('aria-expanded', !isExpanded);
            
            // Toggle menu visibility
            navMenu.classList.toggle('nav-menu--open');
            
            // Prevent body scroll when menu is open
            document.body.style.overflow = isExpanded ? '' : 'hidden';
        });

        // Close menu when clicking on nav links
        const navLinks = navMenu.querySelectorAll('.nav-menu__link');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('nav-menu--open');
                navToggle.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            });
        });

        // Close menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
                navMenu.classList.remove('nav-menu--open');
                navToggle.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
            }
        });

        // Handle escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && navMenu.classList.contains('nav-menu--open')) {
                navMenu.classList.remove('nav-menu--open');
                navToggle.setAttribute('aria-expanded', 'false');
                document.body.style.overflow = '';
                navToggle.focus();
            }
        });
    },

    /**
     * Setup smooth scrolling for navigation links
     */
    setupSmoothScrolling() {
        const navLinks = document.querySelectorAll('a[href^="#"]');
        
        navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                const href = link.getAttribute('href');
                
                // Skip if href is just "#"
                if (href === '#') return;
                
                const target = document.querySelector(href);
                if (!target) return;
                
                e.preventDefault();
                
                // Calculate offset for sticky header
                const headerHeight = document.querySelector('.header').offsetHeight;
                const targetPosition = target.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Update focus for accessibility
                target.setAttribute('tabindex', '-1');
                target.focus();
                target.addEventListener('blur', () => {
                    target.removeAttribute('tabindex');
                }, { once: true });
            });
        });
    },

    /**
     * Setup active navigation highlighting
     */
    setupActiveNavigation() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-menu__link');
        
        if (sections.length === 0 || navLinks.length === 0) return;

        const updateActiveNav = throttle(() => {
            const scrollPosition = window.scrollY + 100;
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.offsetHeight;
                const sectionId = section.getAttribute('id');
                
                if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                    navLinks.forEach(link => {
                        link.classList.remove('nav-menu__link--active');
                        if (link.getAttribute('href') === `#${sectionId}`) {
                            link.classList.add('nav-menu__link--active');
                        }
                    });
                }
            });
        }, 100);

        window.addEventListener('scroll', updateActiveNav);
    }
};

// ===================================
// FORM VALIDATION MODULE
// ===================================

const FormValidation = {
    /**
     * Initialize form validation
     */
    init() {
        this.setupContactForm();
    },

    /**
     * Setup contact form validation and submission
     */
    setupContactForm() {
        const form = document.querySelector('.contact__form');
        if (!form) return;

        const fields = {
            name: form.querySelector('#name'),
            email: form.querySelector('#email'),
            phone: form.querySelector('#phone'),
            message: form.querySelector('#message'),
            privacy: form.querySelector('#privacy')
        };

        // Real-time validation
        Object.entries(fields).forEach(([fieldName, field]) => {
            if (!field) return;

            field.addEventListener('blur', () => {
                this.validateField(fieldName, field);
            });

            field.addEventListener('input', debounce(() => {
                this.clearError(field);
            }, 300));
        });

        // Form submission
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleFormSubmission(form, fields);
        });
    },

    /**
     * Validate individual field
     * @param {string} fieldName - Name of the field
     * @param {Element} field - Field element
     * @returns {boolean} True if field is valid
     */
    validateField(fieldName, field) {
        const value = field.value.trim();
        let isValid = true;
        let errorMessage = '';

        switch (fieldName) {
            case 'name':
                if (!value) {
                    errorMessage = 'O nome é obrigatório.';
                    isValid = false;
                } else if (value.length < 2) {
                    errorMessage = 'O nome deve ter pelo menos 2 caracteres.';
                    isValid = false;
                }
                break;

            case 'email':
                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!value) {
                    errorMessage = 'O email é obrigatório.';
                    isValid = false;
                } else if (!emailRegex.test(value)) {
                    errorMessage = 'Por favor, insira um email válido.';
                    isValid = false;
                }
                break;

            case 'phone':
                if (value && !/^[+]?[\d\s\-()]+$/.test(value)) {
                    errorMessage = 'Por favor, insira um número de telefone válido.';
                    isValid = false;
                }
                break;

            case 'message':
                if (!value) {
                    errorMessage = 'A mensagem é obrigatória.';
                    isValid = false;
                } else if (value.length < 10) {
                    errorMessage = 'A mensagem deve ter pelo menos 10 caracteres.';
                    isValid = false;
                }
                break;

            case 'privacy':
                if (!field.checked) {
                    errorMessage = 'Deve aceitar a política de privacidade.';
                    isValid = false;
                }
                break;
        }

        if (!isValid) {
            this.showError(field, errorMessage);
        } else {
            this.clearError(field);
        }

        return isValid;
    },

    /**
     * Show error message for field
     * @param {Element} field - Field element
     * @param {string} message - Error message
     */
    showError(field, message) {
        const errorElement = document.querySelector(`#${field.id}-error`);
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.style.display = 'block';
        }
        
        field.classList.add('form-input--error');
        field.setAttribute('aria-invalid', 'true');
    },

    /**
     * Clear error message for field
     * @param {Element} field - Field element
     */
    clearError(field) {
        const errorElement = document.querySelector(`#${field.id}-error`);
        if (errorElement) {
            errorElement.textContent = '';
            errorElement.style.display = 'none';
        }
        
        field.classList.remove('form-input--error');
        field.setAttribute('aria-invalid', 'false');
    },

    /**
     * Handle form submission
     * @param {Element} form - Form element
     * @param {Object} fields - Form fields
     */
    handleFormSubmission(form, fields) {
        let isFormValid = true;

        // Validate all fields
        Object.entries(fields).forEach(([fieldName, field]) => {
            if (field && !this.validateField(fieldName, field)) {
                isFormValid = false;
            }
        });

        if (!isFormValid) {
            // Focus on first error field
            const firstErrorField = form.querySelector('.form-input--error, [aria-invalid="true"]');
            if (firstErrorField) {
                firstErrorField.focus();
            }
            return;
        }

        // Simulate form submission
        const submitButton = form.querySelector('.form-submit');
        const originalText = submitButton.textContent;
        
        submitButton.textContent = 'A enviar...';
        submitButton.disabled = true;

        setTimeout(() => {
            alert('Mensagem enviada com sucesso! Entraremos em contacto em breve.');
            form.reset();
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }, 2000);
    }
};

// ===================================
// GALLERY MODULE
// ===================================

const Gallery = {
    currentImageIndex: 0,
    images: [],

    /**
     * Initialize gallery functionality
     */
    init() {
        this.setupGalleryItems();
        this.setupLightbox();
    },

    /**
     * Setup gallery item click handlers
     */
    setupGalleryItems() {
        const galleryItems = document.querySelectorAll('.gallery__item');
        
        this.images = Array.from(galleryItems).map(item => ({
            element: item,
            caption: item.querySelector('.gallery__caption')?.textContent || ''
        }));

        galleryItems.forEach((item, index) => {
            item.addEventListener('click', () => {
                this.openLightbox(index);
            });

            // Keyboard support
            item.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.openLightbox(index);
                }
            });

            // Make items focusable
            item.setAttribute('tabindex', '0');
            item.setAttribute('role', 'button');
            item.setAttribute('aria-label', `Ver imagem: ${item.querySelector('.gallery__caption')?.textContent || 'Imagem da galeria'}`);
        });
    },

    /**
     * Setup lightbox functionality
     */
    setupLightbox() {
        const lightbox = document.querySelector('#lightbox');
        if (!lightbox) return;

        const closeBtn = lightbox.querySelector('.lightbox__close');
        const overlay = lightbox.querySelector('.lightbox__overlay');
        const prevBtn = lightbox.querySelector('.lightbox__prev');
        const nextBtn = lightbox.querySelector('.lightbox__next');

        // Close lightbox handlers
        [closeBtn, overlay].forEach(element => {
            if (element) {
                element.addEventListener('click', () => this.closeLightbox());
            }
        });

        // Navigation handlers
        if (prevBtn) {
            prevBtn.addEventListener('click', () => this.previousImage());
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', () => this.nextImage());
        }

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (!lightbox.classList.contains('lightbox--open')) return;

            switch (e.key) {
                case 'Escape':
                    this.closeLightbox();
                    break;
                case 'ArrowLeft':
                    this.previousImage();
                    break;
                case 'ArrowRight':
                    this.nextImage();
                    break;
            }
        });
    },

    /**
     * Open lightbox with specific image
     * @param {number} index - Image index
     */
    openLightbox(index) {
        const lightbox = document.querySelector('#lightbox');
        if (!lightbox || !this.images[index]) return;

        this.currentImageIndex = index;
        this.updateLightboxContent();
        
        lightbox.classList.add('lightbox--open');
        lightbox.setAttribute('aria-hidden', 'false');
        
        // Focus management
        const closeBtn = lightbox.querySelector('.lightbox__close');
        if (closeBtn) {
            closeBtn.focus();
        }

        // Prevent body scroll
        document.body.style.overflow = 'hidden';
    },

    /**
     * Close lightbox
     */
    closeLightbox() {
        const lightbox = document.querySelector('#lightbox');
        if (!lightbox) return;

        lightbox.classList.remove('lightbox--open');
        lightbox.setAttribute('aria-hidden', 'true');
        
        // Restore body scroll
        document.body.style.overflow = '';

        // Return focus to the gallery item
        const currentItem = this.images[this.currentImageIndex]?.element;
        if (currentItem) {
            currentItem.focus();
        }
    },

    /**
     * Show previous image
     */
    previousImage() {
        this.currentImageIndex = (this.currentImageIndex - 1 + this.images.length) % this.images.length;
        this.updateLightboxContent();
    },

    /**
     * Show next image
     */
    nextImage() {
        this.currentImageIndex = (this.currentImageIndex + 1) % this.images.length;
        this.updateLightboxContent();
    },

    /**
     * Update lightbox content
     */
    updateLightboxContent() {
        const lightbox = document.querySelector('#lightbox');
        const caption = lightbox.querySelector('.lightbox__caption');
        
        if (caption && this.images[this.currentImageIndex]) {
            caption.textContent = this.images[this.currentImageIndex].caption;
        }

        // Update navigation button states
        const prevBtn = lightbox.querySelector('.lightbox__prev');
        const nextBtn = lightbox.querySelector('.lightbox__next');
        
        if (prevBtn && nextBtn) {
            prevBtn.style.display = this.images.length > 1 ? 'block' : 'none';
            nextBtn.style.display = this.images.length > 1 ? 'block' : 'none';
        }
    }
};

// ===================================
// FILTER MODULE
// ===================================

const Filter = {
    /**
     * Initialize filter functionality
     */
    init() {
        this.setupClassFilters();
    },

    /**
     * Setup class filtering functionality
     */
    setupClassFilters() {
        const filterButtons = document.querySelectorAll('.filter-btn');
        const classCards = document.querySelectorAll('.class-card');

        if (filterButtons.length === 0 || classCards.length === 0) return;

        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                const filter = button.getAttribute('data-filter');
                
                // Update active button
                filterButtons.forEach(btn => btn.classList.remove('filter-btn--active'));
                button.classList.add('filter-btn--active');
                
                // Filter cards
                this.filterCards(classCards, filter);
                
                // Announce change to screen readers
                this.announceFilterChange(filter);
            });
        });
    },

    /**
     * Filter class cards based on level
     * @param {NodeList} cards - Class cards
     * @param {string} filter - Filter value
     */
    filterCards(cards, filter) {
        cards.forEach(card => {
            const cardLevels = card.getAttribute('data-level');
            const shouldShow = filter === 'all' || cardLevels.includes(filter);
            
            if (shouldShow) {
                card.style.display = 'block';
                card.setAttribute('aria-hidden', 'false');
                // Animate in
                setTimeout(() => {
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                }, 50);
            } else {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.setAttribute('aria-hidden', 'true');
                // Hide after animation
                setTimeout(() => {
                    card.style.display = 'none';
                }, 300);
            }
        });
    },

    /**
     * Announce filter change to screen readers
     * @param {string} filter - Filter value
     */
    announceFilterChange(filter) {
        const announcement = document.createElement('div');
        announcement.setAttribute('aria-live', 'polite');
        announcement.setAttribute('aria-atomic', 'true');
        announcement.className = 'sr-only';
        
        const filterText = filter === 'all' ? 'todas as modalidades' : `modalidades de nível ${filter}`;
        announcement.textContent = `A mostrar ${filterText}`;
        
        document.body.appendChild(announcement);
        
        setTimeout(() => {
            document.body.removeChild(announcement);
        }, 1000);
    }
};

// ===================================
// ANIMATIONS MODULE
// ===================================

const Animations = {
    /**
     * Initialize animations
     */
    init() {
        this.setupScrollReveal();
        this.setupCounterAnimations();
    },

    /**
     * Setup scroll reveal animations
     */
    setupScrollReveal() {
        const revealElements = document.querySelectorAll('.reveal, .class-card, .pricing-card, .testimonial');
        
        if (revealElements.length === 0) return;

        const revealOnScroll = throttle(() => {
            revealElements.forEach(element => {
                if (isInViewport(element) && !element.classList.contains('reveal--visible')) {
                    element.classList.add('reveal--visible');
                }
            });
        }, 100);

        // Initial check
        revealOnScroll();
        
        // Check on scroll
        window.addEventListener('scroll', revealOnScroll);
    },

    /**
     * Setup counter animations for statistics
     */
    setupCounterAnimations() {
        const statNumbers = document.querySelectorAll('.stat__number[data-count]');
        let animated = false;

        const animateCounters = () => {
            if (animated) return;

            const statsSection = document.querySelector('.about__stats');
            if (!statsSection || !isInViewport(statsSection)) return;

            animated = true;
            
            statNumbers.forEach(element => {
                const targetCount = parseInt(element.getAttribute('data-count'));
                animateNumber(element, 0, targetCount, 2000);
            });
        };

        const checkCounters = throttle(animateCounters, 100);
        window.addEventListener('scroll', checkCounters);
        
        // Initial check
        checkCounters();
    }
};

// ===================================
// ACCESSIBILITY MODULE
// ===================================

const Accessibility = {
    /**
     * Initialize accessibility enhancements
     */
    init() {
        this.setupKeyboardNavigation();
        this.setupFocusManagement();
        this.setupARIALabels();
    },

    /**
     * Setup keyboard navigation enhancements
     */
    setupKeyboardNavigation() {
        // Skip link functionality is handled in CSS
        
        // Ensure all interactive elements are keyboard accessible
        const interactiveElements = document.querySelectorAll('button, a, input, select, textarea, [tabindex]');
        
        interactiveElements.forEach(element => {
            if (!element.hasAttribute('tabindex') && element.tagName !== 'A' && element.tagName !== 'BUTTON' && element.tagName !== 'INPUT' && element.tagName !== 'SELECT' && element.tagName !== 'TEXTAREA') {
                element.setAttribute('tabindex', '0');
            }
        });
    },

    /**
     * Setup focus management
     */
    setupFocusManagement() {
        // Trap focus in modal when open
        const lightbox = document.querySelector('#lightbox');
        if (!lightbox) return;

        const focusableElements = 'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])';
        
        lightbox.addEventListener('keydown', (e) => {
            if (!lightbox.classList.contains('lightbox--open')) return;
            
            if (e.key === 'Tab') {
                const focusableContent = lightbox.querySelectorAll(focusableElements);
                const firstFocusable = focusableContent[0];
                const lastFocusable = focusableContent[focusableContent.length - 1];

                if (e.shiftKey) {
                    if (document.activeElement === firstFocusable) {
                        lastFocusable.focus();
                        e.preventDefault();
                    }
                } else {
                    if (document.activeElement === lastFocusable) {
                        firstFocusable.focus();
                        e.preventDefault();
                    }
                }
            }
        });
    },

    /**
     * Setup dynamic ARIA labels
     */
    setupARIALabels() {
        // Update ARIA labels for dynamic content
        const updateARIALabels = () => {
            // Update navigation current page
            const activeNavLink = document.querySelector('.nav-menu__link--active');
            if (activeNavLink) {
                document.querySelectorAll('.nav-menu__link').forEach(link => {
                    link.removeAttribute('aria-current');
                });
                activeNavLink.setAttribute('aria-current', 'page');
            }
        };

        // Update on scroll
        window.addEventListener('scroll', throttle(updateARIALabels, 200));
    }
};

// ===================================
// PERFORMANCE MODULE
// ===================================

const Performance = {
    /**
     * Initialize performance optimizations
     */
    init() {
        this.setupLazyLoading();
        this.setupImageOptimization();
    },

    /**
     * Setup lazy loading for images
     */
    setupLazyLoading() {
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        if (img.dataset.src) {
                            img.src = img.dataset.src;
                            img.removeAttribute('data-src');
                        }
                        observer.unobserve(img);
                    }
                });
            });

            document.querySelectorAll('img[data-src]').forEach(img => {
                imageObserver.observe(img);
            });
        }
    },

    /**
     * Setup image optimization
     */
    setupImageOptimization() {
        // Add loading="lazy" to images below the fold
        const images = document.querySelectorAll('img');
        images.forEach((img, index) => {
            if (index > 2) { // Skip first few images (above the fold)
                img.setAttribute('loading', 'lazy');
            }
        });
    }
};

// ===================================
// MAIN APPLICATION
// ===================================

const DanceSchoolApp = {
    /**
     * Initialize the application
     */
    init() {
        // Wait for DOM to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.start());
        } else {
            this.start();
        }
    },

    /**
     * Start the application
     */
    start() {
        try {
            // Initialize all modules
            Navigation.init();
            FormValidation.init();
            Gallery.init();
            Filter.init();
            Animations.init();
            Accessibility.init();
            Performance.init();

            // Add loaded class to body for CSS animations
            document.body.classList.add('loaded');

            console.log('🎭 Escola de Dança Ritmo & Movimento - Site carregado com sucesso!');
        } catch (error) {
            console.error('Erro ao inicializar a aplicação:', error);
        }
    }
};

// ===================================
// ERROR HANDLING
// ===================================

// Global error handler
window.addEventListener('error', (e) => {
    console.error('Erro JavaScript:', e.error);
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', (e) => {
    console.error('Promise rejeitada:', e.reason);
});

// ===================================
// INITIALIZE APPLICATION
// ===================================

DanceSchoolApp.init();

// Export for potential module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        Navigation,
        FormValidation,
        Gallery,
        Filter,
        Animations,
        Accessibility,
        Performance,
        DanceSchoolApp
    };
}
