# Escola de Dança Ritmo & Movimento

Este é um site moderno e acessível para uma escola de dança, desenvolvido com HTML5, CSS3 e JavaScript vanilla.

## Características

- **Acessibilidade**: Seguindo as diretrizes WCAG 2.1
- **Responsivo**: Design mobile-first
- **Performance**: Otimizado para carregamento rápido
- **SEO**: Estrutura semântica e meta tags apropriadas
- **Clean Code**: Código bem estruturado e documentado

## Estrutura

- `index.html` - Página principal
- `css/styles.css` - Estilos CSS
- `js/script.js` - Funcionalidades JavaScript
- `images/` - Imagens do site

## Funcionalidades

- Menu de navegação responsivo
- Formulário de contacto com validação
- Galeria interativa com lightbox
- Filtros de modalidades
- Animações suaves
- Contador animado de estatísticas

## Tecnologias

- HTML5 semântico
- CSS3 com custom properties
- JavaScript ES6+
- Design responsivo
- Acessibilidade WCAG 2.1
